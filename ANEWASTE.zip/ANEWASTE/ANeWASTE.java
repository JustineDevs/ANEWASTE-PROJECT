/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.javaproject.anewaste;

/**
 *
 * @author TraderG
 */
public class ANeWASTE {

    public static void main(String[] args) {
        Preview view = new Preview();
        view.show();
    }
}
